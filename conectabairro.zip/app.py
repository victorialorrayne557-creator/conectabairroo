from flask import Flask, render_template, request, redirect, session
import sqlite3
import re

app = Flask(__name__)
app.secret_key = '12345'


# CONEXÃO COM O BANCO
def conectar_db():
    conectar = sqlite3.connect('cadastro.db')
    return conectar


# CRIAR TABELA
def criar_tabela():

    conectar = conectar_db()
    cursor = conectar.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT NOT NULL,
            senha TEXT NOT NULL,
            servico TEXT
        )
    ''')

    conectar.commit()
    conectar.close()


# PÁGINA INICIAL
@app.route('/')
def index():
    return render_template('index.html')


# HOME
@app.route('/home')
def home():
    return render_template('home.html')


# LOGIN
@app.route('/login', methods=['GET', 'POST'])
def login():

    if request.method == 'POST':

        email = request.form['email']
        senha = request.form['senha']

        conectar = conectar_db()
        cursor = conectar.cursor()

        cursor.execute(
            "SELECT * FROM clientes WHERE email=? AND senha=?",
            (email, senha)
        )

        usuario = cursor.fetchone()

        conectar.close()

        if usuario:
            return redirect('/home')

        else:
            return "Email ou senha incorretos!"

    return render_template('login.html')


# CADASTRO
@app.route('/cadastro', methods=['GET', 'POST'])
def cadastro():

    if request.method == 'POST':

        nome = request.form['nome']
        email = request.form['email']
        senha = request.form['senha']

        conectar = conectar_db()
        cursor = conectar.cursor()

        cursor.execute(
            """
            INSERT INTO clientes (nome, email, senha)
            VALUES (?, ?, ?)
            """,
            (nome, email, senha)
        )

        conectar.commit()
        conectar.close()

        return redirect('/login')

    return render_template('cadastro.html')


# CONFIG
@app.route('/config')
def config():
    return render_template('config.html')


# FAVORITOS
@app.route('/favoritos')
def favoritos():
    return render_template('favoritos.html')


# EDITAR PERFIL
@app.route('/editar_perfil', methods=['POST'])
def editar_perfil():

    if 'usuario_id' not in session:
        return redirect('/login')

    nome = request.form['nome']
    email = request.form['email']
    servico = request.form['servico']

    usuario_id = session['usuario_id']

    conectar = conectar_db()
    cursor = conectar.cursor()

    cursor.execute(
        """
        UPDATE clientes
        SET nome=?, email=?, servico=?
        WHERE id=?
        """,
        (nome, email, servico, usuario_id)
    )

    conectar.commit()
    conectar.close()

    return redirect('/config')


# EXECUTAR
if __name__ == '__main__':
    criar_tabela()
    app.run(debug=True)